/// <reference types="vite/client" />

declare module '*.css?inline' {
  const content: string
  export default content
}

interface ImportMetaEnv {
  readonly VITE_API_BASE_URL?: string
  readonly VITE_AUTH_TOKEN?: string
}
interface ImportMeta {
  readonly env: ImportMetaEnv
}
